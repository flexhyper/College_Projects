
package vehler;

import java.text.SimpleDateFormat;
import java.util.Date;


public class DateTime {
    public String getTime()
    {
      Date d=new Date();
        SimpleDateFormat df=new SimpleDateFormat("HH:mm");
        String date=df.format(d);
        return date;
    }
    public String getDate()
    {
      Date d=new Date();
        SimpleDateFormat df=new SimpleDateFormat("dd/MM/yyyy");
        String date=df.format(d);
        return date;
    }
}
