
package vehler;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Vehicle {
    private String Model,Version,Color,plateNo,registrationDate,expirationDate;
    
    
    Vehicle()
    {
        
    }
    Vehicle(String Model,String Version,String Color,String plateNo,String registrationDate,String expirationDate)
    {
        this.Model=Model;
        this.Version=Version;
        this.Color=Color;
        this.plateNo=plateNo;
        this.registrationDate=registrationDate;
        this.expirationDate=expirationDate;
    }

   public String getModel()
    {
        return Model;
    }
   public String getVersion()
    {
        return Version;
    }
   public String getColor()
    {
        return Color;
    }
   public String getPlateNo()
    {
        return plateNo;
    }
   public String getregistrationDate()
    {
        return registrationDate;
    }
   public String getExpirationDate()
    {
        return expirationDate;
    }

    
}
